"""GoHub Seat Inventory Service."""
